import React from 'react'

export const Comment = (props) => {
  return (
    <div className="Comment">
        <h1>User details {props.name} </h1>
  </div>
  )
}
