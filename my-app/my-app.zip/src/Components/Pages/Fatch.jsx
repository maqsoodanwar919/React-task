import React from 'react'

export const Fatch = () => {
  return (
    <div>Fatch</div>
  )
}
