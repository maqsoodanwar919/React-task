import React from 'react'

const Read = () => {
  return (
    <div>
         <h1 className='text-center my-4'>Reads Form With React js</h1> 
    </div>
  )
}

export default Read